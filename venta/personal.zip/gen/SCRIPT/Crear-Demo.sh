#!/bin/bash
IP="/etc/MEUIPADM"
tmpusr () {
time="$1"
timer=$(( $time * 60 ))
timer2="'$timer's"
echo "#!/bin/bash
sleep $timer2
kill"' $(ps -u '"$2 |awk '{print"' $1'"}') 1>/dev/null 2>/dev/null
userdel --force $2
rm -rf /tmp/$2
exit" > /tmp/$2
}
echo -e "\033[33m================================================\033[0m"
echo -e "\033[33m         USUARIOS TEMPORALES [ADMIN 2020]\033[0m"
echo -e "\033[31m        ESTOS USUARIOS NO PARECERAN EN EL NOTIFY \033[0m"
echo -e "\033[33m================================================\033[0m"
echo -e "\033[33m[?]NOMBRE DEL USUARIO:\033[0m";     read -p " NOMBRE: " name 
     
if [ "$name" = "" ]; then
echo -e "\033[33m================================================\033[0m"
echo -e "\033[1;31m           [X]NO ESCRIBIO NINGUN NOMBRE!!\033[0m"
echo -e "\033[33m       AGREGA UN USUARIO Y NO PIERDAS TIEMPO!!\033[0m"
echo -e "\033[33m================================================\033[0m"
sleep 3s
/etc/ger-frm/Crear-Demo.sh
fi
if cat /etc/passwd |grep $name: |grep -vi [a-z]$name |grep -v [0-9]$name > /dev/null
then
echo -e "\033[33m================================================\033[0m"
echo -e "\033[1;31m           [X] USUARIO $name YA EXISTE\033[0m"
echo -e "\033[33m        USA OTRO USUARIO Y NO PIERDAS TIEMPO!\033[0m"
echo -e "\033[33m================================================\033[0m"
sleep 3s
/etc/ger-frm/Crear-Demo.sh
fi
echo -e "\033[31m[>] Clave para el Usuario:  $name:\033[0;37m"; read -p " CONTRASEÑA: " pass
echo -e "\033[31m[>] Tiempo de Duracion En Minutos:\033[0;37m"; read -p " MINUTOS: " tmp
if [ "$tmp" = "" ]; then
tmp="30"
echo -e "\033[1;32mFue Definido 30 minutos!\033[0m"
sleep 2s
fi
useradd -M -s /bin/false $name
(echo $pass; echo $pass)|passwd $name 2>/dev/null
touch /tmp/$name
tmpusr $tmp $name
chmod 777 /tmp/$name
touch /tmp/cmd
chmod 777 /tmp/cmd
echo "nohup /tmp/$name & >/dev/null" > /tmp/cmd
/tmp/cmd 2>/dev/null 1>/dev/null
rm -rf /tmp/cmd 
#echo "$pass" > /etc/VpsPackdir/senha/$name
#echo "$tmp" > /etc/VpsPackdir/limite/$name
echo -e "\033[33m================================================\033[0m"
echo -e "\033[31m      USUARIO CREADO CON EXITO [by @Alexmod80]\033[0m"
echo -e "\033[33m================================================\033[0m"
echo -e "\033[31m      IP: \033[37m      $(cat /etc/MEUIPADM)"
echo -e "\033[31m      USUARIO:  \033[0m$name"
echo -e "\033[32m      CLAVE:    \033[0m$pass"
echo -e "\033[33m      DURACION: \033[0m$tmp minutos"
echo -e ""
echo -e "\033[0mEl Usuario > $name Se Auto-Eliminara En > $tmp Minutos"
echo -e "\033[33m================================================\033[0m"

read -p "PARA VOLVER AL MENU PRESIONA [ENTER] " then
adm
exit
