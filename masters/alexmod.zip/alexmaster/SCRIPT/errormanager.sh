#!/bin/bash
declare -A cor=( [0]="\033[1;37m" [1]="\033[1;34m" [2]="\033[1;35m" [3]="\033[1;32m" [4]="\033[1;31m" [5]="\033[1;33m" [6]="\E[44;1;37m" [7]="\E[41;1;37m" )
barra="\033[0m\e[31m======================================================\033[1;37m"
SCPdir="/etc/newadm" && [[ ! -d ${SCPdir} ]] && exit 1
SCPfrm="/etc/ger-frm" && [[ ! -d ${SCPfrm} ]] && exit
SCPinst="/etc/ger-inst" && [[ ! -d ${SCPinst} ]] && exit
SCPidioma="${SCPdir}/idioma" && [[ ! -e ${SCPidioma} ]] && touch ${SCPidioma}

fun_bar () {
comando="$1"
 _=$(
$comando > /dev/null 2>&1
) & > /dev/null
pid=$!
while [[ -d /proc/$pid ]]; do
echo -ne " \033[1;33m["
   for((i=0; i<10; i++)); do
   echo -ne "\033[1;31m**"
   sleep 0.2
   done
echo -ne "\033[1;33m]"
sleep 1s
echo
tput cuu1 && tput dl1
done
echo -e " \033[1;33m[\033[1;31mFINALIZADA\033[1;33m] - \033[1;32m100%\033[0m"
sleep 1s
}
elimi_web(){
clear
msg -bar
msg -ama " $(fun_trans "INICIANDO DESINSTALACION WEBMIN")"
msg -bar
fun_bar "apt-get purge webmin -y"
fun_bar "apt-get autoremove -y"
fun_bar "apt-get remove webmin -y"
msg -ama " $(fun_trans "WEBMIN DESINSTALADA")"
msg -bar
}
elimi_openvpn (){
msg -bar
msg -ama " $(fun_trans "DESINSTALAR OPENVPN")"
msg -bar
   if [[ "$OS" = 'debian' ]]; then
   fun_bar "apt-get remove --purge -y openvpn openvpn-blacklist"
   else
   fun_bar "yum remove openvpn -y"
   fi
   tuns=$(cat /etc/modules | grep -v tun) && echo -e "$tuns" > /etc/modules
   rm -rf /etc/openvpn && rm -rf /usr/share/doc/openvpn*
   msg -bar
   msg -ama " $(fun_trans "Procedimiento completado")"
   msg -bar
}
pid_kill (){
[[ -z $1 ]] && refurn 1
pids="$@"
for pid in $(echo $pids); do
kill -9 $pid &>/dev/null
done
}
remove_fun () {
msg -ama "$(fun_trans "Parando Proxy Python")"
msg -bar
pidproxy=$(ps x | grep "PPub.py" | grep -v "grep" | awk -F "pts" '{print $1}') && [[ ! -z $pidproxy ]] && pid_kill $pidproxy
pidproxy2=$(ps x | grep "PPriv.py" | grep -v "grep" | awk -F "pts" '{print $1}') && [[ ! -z $pidproxy2 ]] && pid_kill $pidproxy2
pidproxy3=$(ps x | grep "PDirect.py" | grep -v "grep" | awk -F "pts" '{print $1}') && [[ ! -z $pidproxy3 ]] && pid_kill $pidproxy3
pidproxy4=$(ps x | grep "POpen.py" | grep -v "grep" | awk -F "pts" '{print $1}') && [[ ! -z $pidproxy4 ]] && pid_kill $pidproxy4
pidproxy5=$(ps x | grep "PGet.py" | grep -v "grep" | awk -F "pts" '{print $1}') && [[ ! -z $pidproxy5 ]] && pid_kill $pidproxy5
pidproxy6=$(ps x | grep "scktcheck" | grep -v "grep" | awk -F "pts" '{print $1}') && [[ ! -z $pidproxy6 ]] && pid_kill $pidproxy6
echo -e " $(fun_trans "proxy python Parado")"
msg -bar
}

elimi_dropbear () {
msg -bar
msg -ama " $(fun_trans "CORRIGIENDO ERRORES DROPBEAR")"
msg -bar
service dropbear stop
apt-get remove dropbear -y
apt-get purge dropbear -y
rm -rf /etc/default/dropbear
msg -bar
msg -ama " $(fun_trans "PUERTOS COREGIDAS DROPBEAR")"
msg -bar
}

corre_squid () {
msg -bar
msg -ama " $(fun_trans "CORRIGIENDO LOS PUERTOS SQUID")"
msg -bar
apt-get remove squid -y
apt-get purge squid -y
rm -rf /etc/squid
msg -bar
msg -ama " $(fun_trans "ELIMINANDO PUERTOS SQUI3")"
msg -bapt-get remove squid3 -y
apt-get purge squid3 -y
rm -rf /etc/squid3
msg -bar
msg -ama " $(fun_trans "PUERTOS SQUID CORREGIDAS")"
msg -bar
}
ssl_del () {
msg -bar
msg -ama " $(fun_trans "ELIMINANDO PUERTOS SSL")"
msg -bar
service stunnel4 stop
apt-get remove stunnel4 -y
apt-get purge stunnel4 -y
rm -rf /etc/stunnel/stunnel.conf
rm -rf /etc/default/stunnel4
rm -rf /etc/stunnel/stunnel.pem
msg -bar
msg -ama " $(fun_trans "LOS PUERTOS SSL SE HAN DETENIDO CON EXITO")"
msg -bar
}
elimi_fun () {
cowsay -f eyes "Con esta herramienta puedes SOLUCIONAR TUS PROBLEMAS- DETERNER EL PUERTO INECESARIO Y VOLVER A INSTALAR EL PUERTO QUE GUSTES- YA QUE CON ESTA HERRAMIENTA PUEDES CORREGIR TU INCONVENIENCIA.." | lolcat 
figlet .ADMIN~ALEX. | lolcat
echo -e " ${cor[7]} $(fun_trans "DETENER PUERTOS - DROPBEAR - SQUID- SSL- Python") ${cor[6]}[BY ALEX]\033[0m"
echo -e "$barra"
while true; do
echo -e "${cor[4]} [1] > ${cor[5]}$(fun_trans "DETENER PUERTO DROPBEAR")"
echo -e "${cor[4]} [2] > ${cor[5]}$(fun_trans "DETENER EL PUERTO SQUID")"
echo -e "${cor[4]} [3] > ${cor[5]}$(fun_trans "DETENER PUERTOS SSL")"
echo -e "${cor[4]} [4] > ${cor[5]}$(fun_trans "DETENER TODOS LOS PUERTOS PYTHON")"
echo -e "${cor[4]} [5] > ${cor[5]}$(fun_trans "DETENER EL PUERTO OPENVPN")"
echo -e "${cor[4]} [6] > ${cor[5]}$(fun_trans "DETENER EL PUERTO WEBMIN")"
echo -e "${cor[4]} [7] > ${cor[0]}$(fun_trans "SALIR")"
echo -e "${cor[4]} [0] > ${cor[0]}$(fun_trans "VOLVER")\n${barra}"
while [[ ${opx} != @(0|[1-7]) ]]; do
echo -ne "${cor[0]}$(fun_trans "Digite una Opcion"): \033[1;37m" && read opx
tput cuu1 && tput dl1
done
case $opx in
	0)
	menu;;
	1)
	elimi_dropbear
	break;;
	2)
	corre_squid
	break;;
    3)
	ssl_del
	break;;
   4)
   remove_fun
   break;;
   5)
   elimi_openvpn
   break;;
   6)
   elimi_web
   break;;
    7)
	exit;;
  
esac
done
}
elimi_fun